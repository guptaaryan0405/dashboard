import { useState } from 'react';
import { Box, Typography, Button, Divider } from '@mui/material';
import { Add } from '@mui/icons-material';
import { useRunStore } from '../../store/useRunStore';
import { ChartWidget } from './ChartWidget';
import type { ChartConfig } from '../../types';
import { AddChartModal } from '../modals/AddChartModal';

export function ChartWorkspace() {
    const { runs, charts, addChart, removeChart } = useRunStore();
    const [modalOpen, setModalOpen] = useState(false);

    return (
        <Box sx={{ mt: 6 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" fontWeight="bold">Analytics Workspace</Typography>
                <Button
                    variant="outlined"
                    startIcon={<Add />}
                    onClick={() => setModalOpen(true)}
                >
                    Add Chart
                </Button>
            </Box>
            <Divider sx={{ mb: 3 }} />

            {charts.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 8, backgroundColor: 'action.hover', borderRadius: 2 }}>
                    <Typography color="text.secondary">Workspace is empty. Add a chart to begin analysis.</Typography>
                </Box>
            ) : (
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' }, gap: 3 }}>
                    {charts.map(chart => (
                        <ChartWidget
                            key={chart.id}
                            config={chart}
                            runs={runs}
                            onRemove={removeChart}
                        />
                    ))}
                </Box>
            )}

            <AddChartModal
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                onAdd={addChart}
            />
        </Box>
    );
}
