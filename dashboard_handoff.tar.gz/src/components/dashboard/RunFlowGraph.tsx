import { useMemo, useCallback, useEffect } from 'react';
import {
    ReactFlow,
    Background,
    Controls,
    MiniMap,
    useNodesState,
    useEdgesState,
    type Node,
    type Edge,
    type Connection,
    addEdge
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Box, Typography, Paper } from '@mui/material';
import { useRunStore } from '../../store/useRunStore';
import type { Run } from '../../types';

// Simple heuristic layout for DAG (Top to Bottom)
// A real app might use dagre.js, but since users manually link parents, 
// a basic level-based spread works for an MVP.
const nodeWidth = 200;
const nodeHeight = 50;
const xOffset = 250; // Horizontal gap between depths
const yOffset = 100; // Vertical gap between siblings

function generateLayoutElements(runs: Run[]) {
    const nodes: Node[] = [];
    const edges: Edge[] = [];

    // 1. Build adjacency list to compute depths
    const childrenMap = new Map<string, string[]>();
    runs.forEach(r => childrenMap.set(r.id, []));

    let rootIds: string[] = [];

    runs.forEach(r => {
        if (r.parent_id && childrenMap.has(r.parent_id)) {
            childrenMap.get(r.parent_id)!.push(r.id);
        } else {
            rootIds.push(r.id);
        }
    });

    // 2. Assign positions using BFS
    const positions = new Map<string, { x: number, y: number }>();


    // We will place roots on the 0th level, spaced vertically
    let queue: { id: string, depth: number, y: number }[] = rootIds.map((id, index) => ({ id, depth: 0, y: index * yOffset }));

    const depthCounts = new Map<number, number>();

    while (queue.length > 0) {
        const { id, depth, y } = queue.shift()!;

        let nodeY = y;
        if (depthCounts.has(depth)) {
            const count = depthCounts.get(depth)!;
            nodeY = count * yOffset;
            depthCounts.set(depth, count + 1);
        } else {
            depthCounts.set(depth, 1);
        }

        positions.set(id, { x: depth * xOffset, y: nodeY });

        const children = childrenMap.get(id) || [];
        queue.push(...children.map((childId, idx) => ({
            id: childId,
            depth: depth + 1,
            // Attempt to center children under parent roughly
            y: nodeY + (idx - (children.length - 1) / 2) * yOffset
        })));
    }

    // 3. Create ReactFlow elements
    runs.forEach(run => {
        const pos = positions.get(run.id) || { x: 0, y: 0 };
        nodes.push({
            id: run.id,
            position: pos,
            sourcePosition: 'right' as any,
            targetPosition: 'left' as any,
            data: { label: run.run_tag },
            style: {
                width: nodeWidth,
                height: nodeHeight,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 'bold',
                borderRadius: '8px',
                border: '1px solid #ddd',
                backgroundColor: '#fff',
                color: '#333'
            }
        });

        if (run.parent_id) {
            edges.push({
                id: `e-${run.parent_id}-${run.id}`,
                source: run.parent_id,
                target: run.id,
                animated: true,
            });
        }
    });

    return { initialNodes: nodes, initialEdges: edges };
}

export function RunFlowGraph() {
    const { runs, selectedRunId, setSelectedRun, showGraph, setRunParent } = useRunStore();

    const { initialNodes, initialEdges } = useMemo(() => generateLayoutElements(runs), [runs]);

    const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
    const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

    // Sync state when runs change
    useEffect(() => {
        const { initialNodes, initialEdges } = generateLayoutElements(runs);

        // Apply selection style
        const styledNodes = initialNodes.map(n => ({
            ...n,
            style: {
                ...n.style,
                borderColor: n.id === selectedRunId ? '#1a73e8' : '#ddd',
                borderWidth: n.id === selectedRunId ? '2px' : '1px',
                boxShadow: n.id === selectedRunId ? '0 0 10px rgba(26, 115, 232, 0.4)' : 'none'
            }
        }));

        setNodes(styledNodes);
        setEdges(initialEdges);
    }, [runs, selectedRunId, setNodes, setEdges]);

    const onNodeClick = useCallback((_: any, node: Node) => {
        setSelectedRun(node.id);
    }, [setSelectedRun]);

    const onPaneClick = useCallback(() => {
        setSelectedRun(null);
    }, [setSelectedRun]);

    const onConnect = useCallback((connection: Connection) => {
        if (connection.target && connection.source) {
            setRunParent(connection.target, connection.source);
            setEdges((eds) => addEdge(connection, eds));
        }
    }, [setRunParent, setEdges]);

    if (runs.length === 0) {
        return (
            <Paper variant="outlined" sx={{ height: 250, display: showGraph ? 'flex' : 'none', alignItems: 'center', justifyContent: 'center' }}>
                <Typography color="text.secondary">No runs available to visualize. Add a run to generate the lineage graph.</Typography>
            </Paper>
        );
    }

    return (
        <Box sx={{ height: 250, display: showGraph ? 'block' : 'none', width: '100%', border: '1px solid', borderColor: 'divider', borderRadius: 1, backgroundColor: 'background.paper', mb: 3 }}>
            <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onNodeClick={onNodeClick}
                onPaneClick={onPaneClick}
                onConnect={onConnect}
                fitView
                attributionPosition="bottom-right"
            >
                <Background color="#aaa" gap={16} />
                <Controls />
                <MiniMap zoomable pannable />
            </ReactFlow>
        </Box>
    );
}
