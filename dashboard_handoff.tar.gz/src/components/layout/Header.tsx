import { AppBar, Toolbar, Typography, Box, IconButton, InputBase, Select, MenuItem, useTheme, Button, Switch, Tooltip } from '@mui/material';
import { Search, Brightness4, Brightness7, Add, Upload, Download, Settings } from '@mui/icons-material';
import { alpha } from '@mui/material/styles';
import { useRunStore } from '../../store/useRunStore';
import { AutoLoadSettingsDialog } from '../modals/AutoLoadSettingsDialog';
import { useState, useEffect } from 'react';

interface HeaderProps {
    onToggleTheme: () => void;
    onOpenAdd: () => void;
}

export function Header({ onToggleTheme, onOpenAdd }: HeaderProps) {
    const theme = useTheme();
    const searchQuery = useRunStore((state) => state.filters.searchQuery);
    const setSearchQuery = useRunStore((state) => state.setSearchQuery);
    const { runs, fileRef, fileHandle, setLastRefreshTime } = useRunStore();
    const [settingsOpen, setSettingsOpen] = useState(false);

    // 60 Minute Auto-Refresh Polling Loop
    useEffect(() => {
        const intervalId = setInterval(async () => {
            if (fileHandle) {
                try {
                    const file = await fileHandle.getFile();
                    const text = await file.text();
                    const importedRuns = JSON.parse(text);
                    if (Array.isArray(importedRuns)) {
                        useRunStore.setState({ runs: importedRuns });
                        setLastRefreshTime(Date.now());
                        console.log(`Auto-refreshed successfully at ${new Date().toLocaleTimeString()}`);
                    }
                } catch (err) {
                    console.error("Auto-refresh via handle failed:", err);
                }
            } else if (fileRef) {
                try {
                    const text = await fileRef.text();
                    const importedRuns = JSON.parse(text);
                    if (Array.isArray(importedRuns)) {
                        useRunStore.setState({ runs: importedRuns });
                        setLastRefreshTime(Date.now());
                        console.log(`Auto-refreshed via fallback successfully at ${new Date().toLocaleTimeString()}`);
                    }
                } catch (err) {
                    console.error("Auto-refresh via fallback failed:", err);
                }
            }
        }, 60 * 60 * 1000); // 60 minutes

        return () => clearInterval(intervalId);
    }, [fileHandle, fileRef, setLastRefreshTime]);

    const handleExportSession = () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(runs, null, 2));
        const anchorNode = document.createElement('a');
        anchorNode.setAttribute("href", dataStr);
        anchorNode.setAttribute("download", `run_tracker_session_${new Date().toISOString().slice(0, 10)}.json`);
        document.body.appendChild(anchorNode); // required for firefox
        anchorNode.click();
        anchorNode.remove();
    };

    const handleImportSession = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedRuns = JSON.parse(e.target?.result as string);
                if (Array.isArray(importedRuns)) {
                    // Overwrite state completely
                    useRunStore.setState({ runs: importedRuns });
                }
            } catch (err) {
                console.error("Failed to parse session file:", err);
                alert("Invalid session file format.");
            }
        };
        reader.readAsText(file);

        // Reset input so the same file could be imported again if needed
        event.target.value = '';
    };

    return (
        <AppBar position="fixed" color="inherit" elevation={1} sx={{ zIndex: theme.zIndex.drawer + 1 }}>
            <Toolbar>
                <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 0, mr: 4, fontWeight: 'bold' }}>
                    Run Tracker
                </Typography>

                <Box sx={{ minWidth: 150, mr: 4 }}>
                    <Select
                        value="default"
                        size="small"
                        fullWidth
                        variant="standard"
                        disableUnderline
                        sx={{ typography: 'subtitle1' }}
                    >
                        <MenuItem value="default">Project Alpha</MenuItem>
                        <MenuItem value="beta">Project Beta</MenuItem>
                    </Select>
                </Box>

                <Box sx={{
                    position: 'relative',
                    borderRadius: 1,
                    backgroundColor: alpha(theme.palette.common.black, 0.05),
                    '&:hover': { backgroundColor: alpha(theme.palette.common.black, 0.1) },
                    marginRight: theme.spacing(2),
                    marginLeft: 0,
                    width: '100%',
                    [theme.breakpoints.up('sm')]: { marginLeft: theme.spacing(3), width: 'auto' },
                }}>
                    <Box sx={{ padding: theme.spacing(0, 2), height: '100%', position: 'absolute', pointerEvents: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Search color="action" />
                    </Box>
                    <InputBase
                        placeholder="Search run tags..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        sx={{ color: 'inherit', '& .MuiInputBase-input': { padding: theme.spacing(1, 1, 1, 0), paddingLeft: `calc(1em + ${theme.spacing(4)})`, transition: theme.transitions.create('width'), width: '100%', [theme.breakpoints.up('md')]: { width: '40ch' } } }}
                    />
                </Box>

                <Box sx={{ flexGrow: 1 }} />

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mr: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                        <Typography variant="body2" sx={{ mr: 1, color: 'text.secondary' }}>Flow Graph</Typography>
                        <Switch
                            size="small"
                            checked={useRunStore((state) => state.showGraph)}
                            onChange={(e) => useRunStore.getState().setShowGraph(e.target.checked)}
                        />
                    </Box>

                    <Tooltip title="Export Session (JSON)">
                        <IconButton size="small" color="inherit" onClick={handleExportSession}>
                            <Download fontSize="small" />
                        </IconButton>
                    </Tooltip>

                    <Tooltip title="Import Session (JSON)">
                        <IconButton size="small" color="inherit" component="label">
                            <Upload fontSize="small" />
                            <input
                                type="file"
                                hidden
                                accept=".json"
                                onChange={handleImportSession}
                            />
                        </IconButton>
                    </Tooltip>

                    <Tooltip title="Local Auto-Load Settings">
                        <IconButton size="small" color="inherit" onClick={() => setSettingsOpen(true)}>
                            <Settings fontSize="small" />
                            {fileRef || fileHandle ? (
                                <Box sx={{
                                    position: 'absolute',
                                    top: 4, right: 4,
                                    width: 8, height: 8,
                                    bgcolor: 'success.main',
                                    borderRadius: '50%'
                                }} />
                            ) : null}
                        </IconButton>
                    </Tooltip>
                </Box>

                <Button
                    variant="contained"
                    color="primary"
                    startIcon={<Add />}
                    onClick={onOpenAdd}
                    sx={{ mr: 2 }}
                >
                    New Run
                </Button>

                <IconButton sx={{ ml: 1 }} onClick={onToggleTheme} color="inherit">
                    {theme.palette.mode === 'dark' ? <Brightness7 /> : <Brightness4 />}
                </IconButton>
            </Toolbar>

            <AutoLoadSettingsDialog open={settingsOpen} onClose={() => setSettingsOpen(false)} />
        </AppBar>
    );
}
