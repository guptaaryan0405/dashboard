import { useState, useRef, useEffect } from 'react';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    Button, TextField, Box, Typography, Divider, IconButton, Tooltip
} from '@mui/material';
import { FolderOpen, Refresh } from '@mui/icons-material';
import { useRunStore } from '../../store/useRunStore';

interface AutoLoadSettingsDialogProps {
    open: boolean;
    onClose: () => void;
}

export function AutoLoadSettingsDialog({ open, onClose }: AutoLoadSettingsDialogProps) {
    const { autoConfig, fileRef, fileHandle, setAutoRefresh, setLastRefreshTime } = useRunStore();

    const [pathInput, setPathInput] = useState(autoConfig.path);
    const fileInputRef = useRef<HTMLInputElement | null>(null);

    // Sync input when modal opens
    useEffect(() => {
        if (open) {
            setPathInput(autoConfig.path);
        }
    }, [open, autoConfig.path]);

    const handleFileSelect = async () => {
        // Modern File System Access API (Chromium)
        if ('showOpenFilePicker' in window) {
            try {
                const [handle] = await (window as any).showOpenFilePicker({
                    types: [{
                        description: 'JSON Files',
                        accept: { 'application/json': ['.json'] },
                    }],
                    multiple: false
                });

                const file = await handle.getFile();
                setAutoRefresh({ path: pathInput, lastRefreshTime: Date.now() }, file, handle);
                await parseAndLoadFile(file);
                onClose();
            } catch (err) {
                console.log("User cancelled or API failed:", err);
            }
        } else {
            // Firefox Fallback: Use hidden input element
            fileInputRef.current?.click();
        }
    };

    const handleFallbackFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setAutoRefresh({ path: pathInput, lastRefreshTime: Date.now() }, file, null);
        await parseAndLoadFile(file);

        // Reset input
        event.target.value = '';
        onClose();
    };

    const parseAndLoadFile = async (file: File) => {
        try {
            const text = await file.text();
            const importedRuns = JSON.parse(text);
            if (Array.isArray(importedRuns)) {
                useRunStore.setState({ runs: importedRuns });
                setLastRefreshTime(Date.now());
            }
        } catch (err) {
            console.error("Failed to parse auto-refresh file:", err);
            alert("Could not load runs from the selected file. Ensure it is valid JSON.");
        }
    };

    const handleManualRefresh = async () => {
        if (fileHandle) {
            try {
                // Request updated file reference from the handle
                const file = await fileHandle.getFile();
                await parseAndLoadFile(file);
            } catch (err) {
                console.error("Stale file handle, please re-select:", err);
                alert("Browser lost permission to read the file. Please re-select it.");
            }
        } else if (fileRef) {
            // Fallback: the File object might reflect underlying OS updates depending on browser engine
            try {
                await parseAndLoadFile(fileRef);
            } catch (err) {
                console.error("Stale file reference, please re-select:", err);
                alert("Browser lost reference to the file. Please re-select it.");
            }
        }
    };

    const isTracking = fileRef !== null || fileHandle !== null;

    return (
        <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
            <DialogTitle>Auto-Load Settings</DialogTitle>
            <DialogContent>
                <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>

                    <Typography variant="body2" color="text.secondary">
                        The dashboard can automatically refresh bounds from a local JSON file path every 60 minutes.
                        Because of browser security models, you must manually choose the file initially.
                    </Typography>

                    <TextField
                        label="Expected ETX File Path (For Reference)"
                        value={pathInput}
                        onChange={(e) => setPathInput(e.target.value)}
                        fullWidth
                        size="small"
                        helperText="The dashboard will remember this path and try to sync memory."
                    />

                    <Divider sx={{ my: 1 }} />

                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', p: 2, bgcolor: isTracking ? 'success.light' : 'background.paper', borderRadius: 1, border: '1px solid', borderColor: isTracking ? 'success.main' : 'divider' }}>
                        <Box>
                            <Typography variant="subtitle2" fontWeight="bold">
                                {isTracking ? "Currently Tracking File" : "No File Tracking"}
                            </Typography>
                            {isTracking && autoConfig.lastRefreshTime && (
                                <Typography variant="caption" color="text.secondary">
                                    Last Refreshed: {new Date(autoConfig.lastRefreshTime).toLocaleTimeString()}
                                </Typography>
                            )}
                        </Box>

                        <Box sx={{ display: 'flex', gap: 1 }}>
                            {isTracking && (
                                <Tooltip title="Force Refresh Now">
                                    <IconButton size="small" onClick={handleManualRefresh} color="primary">
                                        <Refresh />
                                    </IconButton>
                                </Tooltip>
                            )}
                            <Button
                                variant={isTracking ? "outlined" : "contained"}
                                color="primary"
                                size="small"
                                startIcon={<FolderOpen />}
                                onClick={handleFileSelect}
                            >
                                {isTracking ? "Re-Select File" : "Choose File & Start"}
                            </Button>
                        </Box>
                    </Box>

                    {/* Hidden fallback input for Firefox / unsupported browsers */}
                    <input
                        type="file"
                        ref={fileInputRef}
                        style={{ display: 'none' }}
                        accept=".json"
                        onChange={handleFallbackFileChange}
                    />

                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Close</Button>
            </DialogActions>
        </Dialog>
    );
}
