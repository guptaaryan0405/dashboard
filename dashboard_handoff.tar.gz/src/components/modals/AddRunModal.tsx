import { useState, useEffect } from 'react';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    Button, TextField, Box, Typography, Divider,
    FormControl, InputLabel, Select, MenuItem, Grid, Paper
} from '@mui/material';
import { v4 as uuidv4 } from 'uuid';
import { useRunStore } from '../../store/useRunStore';
import { parseLogToMetrics } from '../../utils/logParser';
import type { Run, StageName, StageData } from '../../types';

interface AddRunModalProps {
    open: boolean;
    onClose: () => void;
    existingRunId?: string | null;
}

const STAGES: StageName[] = ['PRECTS', 'CTS', 'POSTROUTE'];

export function AddRunModal({ open, onClose, existingRunId }: AddRunModalProps) {
    const { runs, addRun, updateRun } = useRunStore();

    const [runTag, setRunTag] = useState('');
    const [frequency, setFrequency] = useState('');
    const [parentId, setParentId] = useState<string>('none');

    // Multi-Stage State
    const [stageLogs, setStageLogs] = useState<Record<StageName, string>>({
        PRECTS: '', CTS: '', POSTROUTE: ''
    });

    // Future expansion for manual entry like Area/Leakage/Timing overrides
    const [stageArea, setStageArea] = useState<Record<StageName, string>>({
        PRECTS: '', CTS: '', POSTROUTE: ''
    });
    const [stageLeakage, setStageLeakage] = useState<Record<StageName, string>>({
        PRECTS: '', CTS: '', POSTROUTE: ''
    });
    const [stageWns, setStageWns] = useState<Record<StageName, string>>({
        PRECTS: '', CTS: '', POSTROUTE: ''
    });
    const [stageTns, setStageTns] = useState<Record<StageName, string>>({
        PRECTS: '', CTS: '', POSTROUTE: ''
    });

    useEffect(() => {
        if (open) {
            if (existingRunId) {
                const runToEdit = runs.find(r => r.id === existingRunId);
                if (runToEdit) {
                    setRunTag(runToEdit.run_tag);
                    setFrequency(runToEdit.frequency_ghz?.toString() || '');
                    setParentId(runToEdit.parent_id || 'none');

                    // For editing, we don't try to reverse-engineer the log string. 
                    // We just allow them to paste NEW logs to overwrite, or input manual metrics.
                    setStageLogs({ PRECTS: '', CTS: '', POSTROUTE: '' });

                    const initArea = { PRECTS: '', CTS: '', POSTROUTE: '' };
                    const initLeakage = { PRECTS: '', CTS: '', POSTROUTE: '' };
                    const initWns = { PRECTS: '', CTS: '', POSTROUTE: '' };
                    const initTns = { PRECTS: '', CTS: '', POSTROUTE: '' };

                    STAGES.forEach(stage => {
                        const stageData = runToEdit.stages[stage];
                        if (stageData?.metrics) {
                            initArea[stage] = stageData.metrics.area_mm2?.toString() || '';
                            initLeakage[stage] = stageData.metrics.leakage_mw?.toString() || '';
                        }

                        // Prefill WNS/TNS from 'all' or 'All Paths' if it exists
                        const allMetrics = stageData?.views?.['all'] || stageData?.views?.['All Paths'];
                        if (allMetrics) {
                            initWns[stage] = allMetrics.WNS !== undefined ? allMetrics.WNS.toString() : '';
                            initTns[stage] = allMetrics.TNS !== undefined ? allMetrics.TNS.toString() : '';
                        }
                    });

                    setStageArea(initArea);
                    setStageLeakage(initLeakage);
                    setStageWns(initWns);
                    setStageTns(initTns);
                }
            } else {
                handleReset();
            }
        }
    }, [open, existingRunId, runs]);

    const handleSave = () => {
        if (!runTag) return;

        const baseRunId = existingRunId || uuidv4();
        const baseRunToEdit = runs.find(r => r.id === baseRunId);

        const newStages: Record<string, StageData> = baseRunToEdit ? { ...baseRunToEdit.stages } : {};

        STAGES.forEach(stage => {
            let stageData = newStages[stage] || { stage, views: {}, metrics: {} };
            let hasUpdates = false;

            // 1. Process Logs if pasted
            const logText = stageLogs[stage];
            if (logText && logText.trim().length > 0) {
                const parsedViews = parseLogToMetrics(logText);
                if (Object.keys(parsedViews).length > 0) {
                    // Merge new parsed views with existing
                    stageData.views = { ...stageData.views, ...parsedViews };
                    hasUpdates = true;
                }
            }

            // 2. Process Manual Metrics
            const areaVal = parseFloat(stageArea[stage]);
            const leakVal = parseFloat(stageLeakage[stage]);
            const wnsVal = parseFloat(stageWns[stage]);
            const tnsVal = parseFloat(stageTns[stage]);

            if (!isNaN(areaVal) || !isNaN(leakVal)) {
                stageData.metrics = {
                    ...stageData.metrics,
                    ...(isNaN(areaVal) ? {} : { area_mm2: areaVal }),
                    ...(isNaN(leakVal) ? {} : { leakage_mw: leakVal })
                };
                hasUpdates = true;
            }

            // 3. Process Timing Overrides (apply to 'all' path group implicitly)
            if (!isNaN(wnsVal) || !isNaN(tnsVal)) {
                // Determine which default key exists, default to 'all' if empty
                const defaultKey = stageData.views?.['All Paths'] ? 'All Paths' : 'all';
                const currentViewMetrics = stageData.views?.[defaultKey] || {};

                stageData.views = {
                    ...stageData.views,
                    [defaultKey]: {
                        ...currentViewMetrics,
                        ...(isNaN(wnsVal) ? {} : { WNS: wnsVal }),
                        ...(isNaN(tnsVal) ? {} : { TNS: tnsVal })
                    }
                };
                hasUpdates = true;
            }

            if (hasUpdates || baseRunToEdit?.stages[stage]) {
                newStages[stage] = stageData;
            }
        });

        const compiledRun: Run = {
            id: baseRunId,
            run_tag: runTag,
            frequency_ghz: frequency ? parseFloat(frequency) : undefined,
            parent_id: parentId === 'none' ? undefined : parentId,
            stages: newStages
        };

        if (existingRunId) {
            updateRun(existingRunId, compiledRun);
        } else {
            addRun(compiledRun);
        }

        handleClose();
    };

    const handleReset = () => {
        setRunTag('');
        setFrequency('');
        setParentId('none');
        setStageLogs({ PRECTS: '', CTS: '', POSTROUTE: '' });
        setStageArea({ PRECTS: '', CTS: '', POSTROUTE: '' });
        setStageLeakage({ PRECTS: '', CTS: '', POSTROUTE: '' });
        setStageWns({ PRECTS: '', CTS: '', POSTROUTE: '' });
        setStageTns({ PRECTS: '', CTS: '', POSTROUTE: '' });
    };

    const handleClose = () => {
        handleReset();
        onClose();
    };

    return (
        <Dialog open={open} onClose={handleClose} maxWidth="lg" fullWidth>
            <DialogTitle>{existingRunId ? 'Edit Run Data' : 'Add New Run'}</DialogTitle>
            <DialogContent>
                <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 3 }}>
                    {/* Header Info */}
                    <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 2 }}>
                        <TextField
                            label="Run Tag (Required)"
                            value={runTag}
                            onChange={(e) => setRunTag(e.target.value)}
                            size="small"
                            required
                            autoFocus
                        />
                        <TextField
                            label="Frequency (GHz)"
                            type="number"
                            value={frequency}
                            onChange={(e) => setFrequency(e.target.value)}
                            size="small"
                        />
                        <FormControl size="small">
                            <InputLabel>Parent Run (Branching From)</InputLabel>
                            <Select
                                value={parentId}
                                label="Parent Run (Branching From)"
                                onChange={(e) => setParentId(e.target.value)}
                            >
                                <MenuItem value="none"><em>None (Root)</em></MenuItem>
                                {runs.map(r => (
                                    <MenuItem key={r.id} value={r.id} disabled={r.id === existingRunId}>{r.run_tag}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Box>

                    <Divider sx={{ my: 1 }} />
                    <Typography variant="subtitle2" color="primary">Stage Data Entry (Optional)</Typography>

                    {/* 3 Column Grid for Stages */}
                    <Grid container spacing={3}>
                        {STAGES.map(stage => (
                            <Grid item xs={12} md={4} key={stage}>
                                <Paper variant="outlined" sx={{ p: 2, height: '100%', backgroundColor: 'background.default' }}>
                                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>{stage}</Typography>

                                    <TextField
                                        label="Paste Log Table (Setup/Hold mode...)"
                                        multiline
                                        rows={8}
                                        value={stageLogs[stage]}
                                        onChange={(e) => setStageLogs({ ...stageLogs, [stage]: e.target.value })}
                                        fullWidth
                                        size="small"
                                        placeholder="|     Setup mode     |   all   | reg2reg |\n|           WNS (ns):| -0.039  | -0.004  |"
                                        sx={{ mb: 2, backgroundColor: 'background.paper' }}
                                    />

                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                        Manual Metrics Override
                                    </Typography>
                                    <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                                        <TextField
                                            label="WNS (ns)"
                                            type="number"
                                            value={stageWns[stage]}
                                            onChange={(e) => setStageWns({ ...stageWns, [stage]: e.target.value })}
                                            size="small"
                                            fullWidth
                                            sx={{ backgroundColor: 'background.paper' }}
                                        />
                                        <TextField
                                            label="TNS (ns)"
                                            type="number"
                                            value={stageTns[stage]}
                                            onChange={(e) => setStageTns({ ...stageTns, [stage]: e.target.value })}
                                            size="small"
                                            fullWidth
                                            sx={{ backgroundColor: 'background.paper' }}
                                        />
                                    </Box>
                                    <Box sx={{ display: 'flex', gap: 1 }}>
                                        <TextField
                                            label="Area (mm²)"
                                            type="number"
                                            value={stageArea[stage]}
                                            onChange={(e) => setStageArea({ ...stageArea, [stage]: e.target.value })}
                                            size="small"
                                            fullWidth
                                            sx={{ backgroundColor: 'background.paper' }}
                                        />
                                        <TextField
                                            label="Leakage (mW)"
                                            type="number"
                                            value={stageLeakage[stage]}
                                            onChange={(e) => setStageLeakage({ ...stageLeakage, [stage]: e.target.value })}
                                            size="small"
                                            fullWidth
                                            sx={{ backgroundColor: 'background.paper' }}
                                        />
                                    </Box>
                                </Paper>
                            </Grid>
                        ))}
                    </Grid>

                    <Typography variant="caption" color="text.secondary">
                        Leave fields blank to skip. If editing an existing run, pasting a new log will merge/overwrite existing path groups.
                    </Typography>
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose}>Cancel</Button>
                <Button variant="contained" onClick={handleSave} disabled={!runTag}>
                    {existingRunId ? 'Update Run' : 'Save Run'}
                </Button>
            </DialogActions>
        </Dialog>
    );
}
