import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Run, StageName, ChartConfig } from '../types';
import { generateDummyData } from '../utils/dummyData';

interface FilterState {
    searchQuery: string;
    stages: Record<StageName, boolean>;
    pathGroups: Record<string, boolean>; // Replaced views with open string keys
}

export interface AutoConfig {
    path: string;
    lastRefreshTime: number | null;
}

interface RunState {
    runs: Run[];
    filters: FilterState;
    selectedRunId: string | null;
    showGraph: boolean;
    autoConfig: AutoConfig;
    fileRef: File | null;
    fileHandle: any | null; // For showOpenFilePicker if supported
    charts: ChartConfig[];

    // Actions
    addRun: (run: Run) => void;
    updateRun: (id: string, run: Run) => void;
    deleteRun: (id: string) => void;
    loadDummyData: () => void;
    clearAll: () => void;
    setSearchQuery: (query: string) => void;
    toggleStageFilter: (stage: StageName) => void;
    togglePathGroupFilter: (pg: string) => void;
    setSelectedRun: (id: string | null) => void;
    setShowGraph: (show: boolean) => void;
    setRunParent: (childId: string, parentId: string) => void;
    setAutoRefresh: (config: AutoConfig, fileRef: File | null, fileHandle: any | null) => void;
    setLastRefreshTime: (time: number) => void;
    addChart: (chart: ChartConfig) => void;
    removeChart: (id: string) => void;
}

export const useRunStore = create<RunState>()(
    persist(
        (set) => ({
            runs: [],
            selectedRunId: null,
            showGraph: false,
            autoConfig: {
                path: '/home/<user>/dashboard_input_json/dashboard_session_export.json',
                lastRefreshTime: null
            },
            fileRef: null,
            fileHandle: null,
            filters: {
                searchQuery: '',
                stages: { PRECTS: true, CTS: true, POSTROUTE: true },
                pathGroups: { all: true, reg2reg: true }
            },
            charts: [
                {
                    id: 'default-1',
                    metric: 'WNS',
                    pathGroup: 'all',
                    targetStage: 'POSTROUTE'
                }
            ],
            addRun: (run) => set((state) => ({ runs: [...state.runs, run] })),
            updateRun: (id, updatedRun) => set((state) => ({
                runs: state.runs.map((r) => (r.id === id ? updatedRun : r))
            })),
            deleteRun: (id) => set((state) => ({
                runs: state.runs.filter((r) => r.id !== id)
            })),
            loadDummyData: () => set({ runs: generateDummyData() }),
            clearAll: () => set({ runs: [] }),
            setSearchQuery: (query) => set((state) => ({ filters: { ...state.filters, searchQuery: query } })),
            toggleStageFilter: (stage) => set((state) => ({
                filters: { ...state.filters, stages: { ...state.filters.stages, [stage]: !state.filters.stages[stage] } }
            })),
            togglePathGroupFilter: (pg) => set((state) => ({
                filters: { ...state.filters, pathGroups: { ...state.filters.pathGroups, [pg]: !state.filters.pathGroups[pg] } }
            })),
            setSelectedRun: (id) => set({ selectedRunId: id }),
            setShowGraph: (show) => set({ showGraph: show }),
            setRunParent: (childId, parentId) => set((state) => ({
                runs: state.runs.map((r) => r.id === childId ? { ...r, parent_id: parentId } : r)
            })),
            setAutoRefresh: (config, fileRef, fileHandle) => set({ autoConfig: config, fileRef, fileHandle }),
            setLastRefreshTime: (time) => set((state) => ({ autoConfig: { ...state.autoConfig, lastRefreshTime: time } })),
            addChart: (chart) => set((state) => ({ charts: [...state.charts, chart] })),
            removeChart: (id) => set((state) => ({ charts: state.charts.filter(c => c.id !== id) }))
        }),
        {
            name: 'dashboard-run-storage',
            partialize: (state) => Object.fromEntries(
                Object.entries(state).filter(([key]) => !['fileRef', 'fileHandle'].includes(key))
            ),
        }
    )
);
